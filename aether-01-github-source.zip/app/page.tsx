"use client";

import { useEffect, useRef, useState } from "react";

const modes = [
  { id: "PULSE", label: "脉冲", hint: "节律 / 锐利" },
  { id: "DRIFT", label: "漂移", hint: "流动 / 柔和" },
  { id: "VOID", label: "虚空", hint: "寂静 / 深邃" },
];

export default function Home() {
  const [mode, setMode] = useState("PULSE");
  const [energy, setEnergy] = useState(72);
  const [active, setActive] = useState(false);
  const [signal, setSignal] = useState(0);
  const stageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!active) return;
    const timer = window.setInterval(() => setSignal((value) => value + 1), 900);
    return () => window.clearInterval(timer);
  }, [active]);

  function trackPointer(event: React.PointerEvent<HTMLElement>) {
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width;
    const y = (event.clientY - bounds.top) / bounds.height;
    stageRef.current?.style.setProperty("--mx", `${x * 100}%`);
    stageRef.current?.style.setProperty("--my", `${y * 100}%`);
    stageRef.current?.style.setProperty("--rx", `${(0.5 - y) * 9}deg`);
    stageRef.current?.style.setProperty("--ry", `${(x - 0.5) * 11}deg`);
  }

  const activity = active ? "LIVE" : "STANDBY";
  const wavelength = mode === "PULSE" ? 448 : mode === "DRIFT" ? 532 : 684;

  return (
    <main
      ref={stageRef}
      className={`site mode-${mode.toLowerCase()} ${active ? "is-active" : ""}`}
      style={{ "--energy": energy } as React.CSSProperties}
      onPointerMove={trackPointer}
    >
      <div className="ambient" aria-hidden="true" />
      <div className="grain" aria-hidden="true" />

      <nav className="nav" aria-label="主导航">
        <a className="brand" href="#top" aria-label="Aether 首页">
          <span className="brand-mark">A</span>
          <span>AETHER</span><i>/</i><small>01</small>
        </a>
        <div className="nav-center"><span /> EXPERIMENT 072</div>
        <a className="nav-link" href="#console">控制台 <span>↘</span></a>
      </nav>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><span>✦</span> INTERACTIVE ENERGY STUDY</p>
          <h1>TOUCH THE<br /><em>UNKNOWN.</em></h1>
          <p className="intro">这是一个关于能量、感知与未知边界的互动实验。移动光标，改变频率，看看空间如何回应你。</p>
          <button className="enter-button" onClick={() => setActive(!active)} aria-pressed={active}>
            <span className="button-orbit" aria-hidden="true" />
            {active ? "暂停实验" : "启动实验"}
            <b>{active ? "Ⅱ" : "→"}</b>
          </button>
        </div>

        <div className="energy-stage" aria-label={`能量核心，当前强度 ${energy}%`}>
          <div className="coordinate top">φ 03.14159</div>
          <div className="coordinate side">X +{String(signal).padStart(3, "0")}</div>
          <div className="core-system">
            <div className="orbit orbit-a"><i /><i /><i /></div>
            <div className="orbit orbit-b"><i /><i /></div>
            <div className="orbit orbit-c" />
            <button className="core" onClick={() => setActive(!active)} aria-label={active ? "暂停能量核心" : "启动能量核心"}>
              <span className="core-shell" />
              <span className="core-light" />
              <span className="core-label">{energy}<small>%</small></span>
            </button>
            <div className="scan-line" />
          </div>
          <div className="core-caption"><span>◉</span> REACTIVE FIELD · {activity}</div>
        </div>
      </section>

      <section className="console" id="console" aria-label="能量控制台">
        <div className="mode-panel">
          <p className="panel-label">01 / 选择状态</p>
          <div className="mode-switch" role="group" aria-label="能量模式">
            {modes.map((item) => (
              <button key={item.id} className={mode === item.id ? "selected" : ""} onClick={() => setMode(item.id)}>
                <span>{item.label}</span><small>{item.hint}</small><b>{mode === item.id ? "●" : "○"}</b>
              </button>
            ))}
          </div>
        </div>

        <div className="energy-panel">
          <div className="panel-heading"><p className="panel-label">02 / 能量强度</p><strong>{energy}<small>%</small></strong></div>
          <label className="range-wrap">
            <span className="sr-only">能量强度</span>
            <input type="range" min="18" max="100" value={energy} onChange={(event) => setEnergy(Number(event.target.value))} />
            <i style={{ width: `${energy}%` }} />
          </label>
          <div className="ticks"><span>18</span><span>40</span><span>60</span><span>80</span><span>100</span></div>
        </div>

        <div className="readout-panel">
          <p className="panel-label">03 / 实时读数</p>
          <div className="readouts">
            <div><small>WAVELENGTH</small><strong>{wavelength}<i>nm</i></strong></div>
            <div><small>AMPLITUDE</small><strong>{(energy / 37).toFixed(2)}<i>Å</i></strong></div>
            <div><small>STATE</small><strong className={active ? "live" : ""}>{activity}</strong></div>
          </div>
        </div>
      </section>

      <footer>
        <p>MOVE YOUR POINTER <span>↗</span></p>
        <p>AETHER LAB / SHANGHAI</p>
        <p>© 2026 — SENSE THE SIGNAL</p>
      </footer>
    </main>
  );
}
